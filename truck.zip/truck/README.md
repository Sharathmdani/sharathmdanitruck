# Smart noticeboard web application.

• A responsive website to manage notice board using HTML, CSS, JavaScript for Front-end and Back-end with MySQL for database management.
